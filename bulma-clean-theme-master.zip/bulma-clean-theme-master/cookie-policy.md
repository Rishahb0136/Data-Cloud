---
title: Cookie policy
layout: page
---

An example cookie policy.