---
title: Products
subtitle: Check out our range of products
layout: product-category
show_sidebar: false
sort: price
---

This is an example products page you can use to display a simple listing of your products and their ratings and reviews.