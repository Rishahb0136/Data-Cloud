---
title: My new book title!
subtitle: Example promo page
layout: promo-page
snippet: |-
  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin mollis volutpat dignissim.

  Pellentesque facilisis non urna a suscipit. Aenean et accumsan lorem. Donec diam ex, egestas at fermentum at, sagittis at diam. Nulla vitae lectus nec nulla faucibus gravida.
hero_link: '#'
hero_link_text: Buy now!
hero_image: https://picsum.photos/id/171/800/1000
hero_image_alt: The hero image alt text
hero_image_ratio: is-4by5
about_image: https://i.pravatar.cc/400?img=24
about_image_alt: The about image alt text
about_title: About the author
product_code: ABC123
---

Donec semper nunc quis quam elementum sodales. Vestibulum eget eros vel odio cursus posuere non nec felis. Nunc porta justo odio, in posuere turpis porttitor id. Morbi fringilla, nisi quis facilisis lobortis, eros sem venenatis arcu, vitae varius est felis eu leo. Donec eleifend sapien in arcu mollis egestas. Fusce consectetur nibh in leo elementum cursus.

Etiam in neque quis quam tristique bibendum eu eu lorem. Nulla facilisi. Morbi cursus lacinia suscipit. Maecenas accumsan purus urna, sit amet finibus ligula pellentesque eu. Vivamus risus dui, sagittis id est nec, volutpat rhoncus orci. Nulla fermentum aliquet lectus at congue. Aenean congue elementum libero nec suscipit. Phasellus sed diam ex. Integer et posuere sem.

### Maecenas lacinia lobortis lacus sed gravida

Nunc in nisl at purus mollis vulputate. Sed tincidunt tincidunt risus eget iaculis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam fermentum vehicula maximus. Praesent convallis in lectus sit amet viverra. Etiam nec semper dolor, ut varius tortor. Aliquam at varius erat, non tempor urna. Maecenas porta porta nibh. 

### Creating a promo page

See the documentation for [creating a promo page](/bulma-clean-theme/docs/promo-pages/creating-a-promo-page).
