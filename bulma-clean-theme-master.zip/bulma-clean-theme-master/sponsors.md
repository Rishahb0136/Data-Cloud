---
layout: page
title: Sponsors Page
subtitle: An example sponsors page
sponsors: example_sponsors
show_sidebar: false
---

[View the sponsors docs](/bulma-clean-theme/docs/page-components/sponsors/)